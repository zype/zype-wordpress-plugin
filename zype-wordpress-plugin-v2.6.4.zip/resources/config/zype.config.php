<?php

/**
 * Plugin autoloading configuration.
 */

return get_option(ZYPE_WP_OPTIONS);
