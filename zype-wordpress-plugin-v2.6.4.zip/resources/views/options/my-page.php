<div class="wrap">
    <h1><?php echo $__page->get('title') ?></h1>
    <ul>
        <li>Option 1</li>
        <li>Option 2</li>
    </ul>
    // Custom HTML content
</div>