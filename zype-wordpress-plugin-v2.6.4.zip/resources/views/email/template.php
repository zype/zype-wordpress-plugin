<h3>
    <?php echo $title; ?>
</h3>
<p>
    <?php echo $text; ?>
</p>
