<?php get_header(); ?>

<main class="site-main">
    <div class="hentry zype-auth-wrap">
        <!-- <div class="entry-header">
            <h1 class="entry-title"><?php echo $title ?></h1>
        </div> -->
        <div class="entry-content">
