<?php

namespace ZypeMedia\Models;

class Settings extends Base
{
    public function __construct()
    {
        parent::__construct();
    }
}
