<?php

namespace Themosis\Foundation;

use Illuminate\Http\Request as IlluminateRequest;

class Request extends IlluminateRequest
{
}
