<?php

namespace Themosis\Taxonomy;

use Exception;

class TaxonomyException extends Exception
{
}
