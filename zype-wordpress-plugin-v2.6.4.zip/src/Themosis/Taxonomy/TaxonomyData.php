<?php

namespace Themosis\Taxonomy;

use Themosis\Foundation\DataContainer;

class TaxonomyData extends DataContainer
{
}
