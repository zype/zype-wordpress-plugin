<?php

namespace Themosis\Load;

class Loader extends Load
{
}
