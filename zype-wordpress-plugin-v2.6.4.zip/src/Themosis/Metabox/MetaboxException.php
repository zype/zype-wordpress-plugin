<?php

namespace Themosis\Metabox;

use Exception;

class MetaboxException extends Exception
{
}
