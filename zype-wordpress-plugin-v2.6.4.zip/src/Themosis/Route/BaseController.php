<?php

namespace Themosis\Route;

use Illuminate\Routing\Controller;

class BaseController extends Controller
{
}
