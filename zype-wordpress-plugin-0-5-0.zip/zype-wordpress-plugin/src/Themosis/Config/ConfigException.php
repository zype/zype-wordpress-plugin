<?php

namespace Themosis\Config;

use Exception;

class ConfigException extends Exception
{
}
