<?php

namespace Themosis\Metabox;

use Themosis\Foundation\DataContainer;

class MetaboxData extends DataContainer
{
}
