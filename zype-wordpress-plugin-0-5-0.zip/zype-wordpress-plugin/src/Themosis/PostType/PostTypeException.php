<?php

namespace Themosis\PostType;

use Exception;

class PostTypeException extends Exception
{
}
