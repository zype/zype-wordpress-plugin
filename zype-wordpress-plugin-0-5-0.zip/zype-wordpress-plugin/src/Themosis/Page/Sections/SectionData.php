<?php

namespace Themosis\Page\Sections;

use Themosis\Foundation\DataContainer;

class SectionData extends DataContainer
{
}
