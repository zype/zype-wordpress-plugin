<?php

namespace Themosis\Page;

use Exception;

class OptionException extends Exception
{
}
