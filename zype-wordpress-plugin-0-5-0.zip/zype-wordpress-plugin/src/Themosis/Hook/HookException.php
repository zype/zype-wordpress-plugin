<?php

namespace Themosis\Hook;

use Exception;

class HookException extends Exception
{
}
