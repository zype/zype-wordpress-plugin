<?php

/**
 * Plugin Providers configuration.
 */
return [
    ZypeMedia\Providers\ZypeService::class,
    ZypeMedia\Providers\RoutingService::class,
    ZypeMedia\Providers\HooksService::class,
];