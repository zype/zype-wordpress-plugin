<?php

/**
 * Plugin autoloading configuration.
 */

global $zype_wp_options;
return $zype_wp_options;
