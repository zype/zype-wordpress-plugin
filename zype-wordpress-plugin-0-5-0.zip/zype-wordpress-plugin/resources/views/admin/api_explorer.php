<?php if(!defined('ABSPATH')) die(); ?>
<div class="wrap zype-admin">
  <h2><?php echo get_admin_page_title(); ?></h2>
  <p>Coming soon.</p>
</div>
