<div>
  <h3>Thank you for signing up for channel</h3>
  <p>You can log in with the email address and password you provided at the following URL: </p>
  <p><a href="<?php zype_url('login'); ?>/"><?php zype_url('login'); ?>/</a></p>
  <p></p>
  <p>
    Thanks again
  </p>
</div>
