<h3>Subscription Cancellation</h3>
<p>Sorry to see you go, we hate to lose a subscriber and want to know why.</p>
<p>Send us an email at <a href="mailto:apps@zype.com">apps@zype.com</a> with your feedback.</p>
<p></p>
<p>
  Thanks for watching,<br>
   Zype Staff
</p>
<p>
Zype &amp; zype.com &amp; &copy; <br> 
</p>