<div>
  <h3>New Subscription</h3>
  <p>Thank you for subscribing to channel, we know you'll enjoy it!</p>
  <p>You can log in with the email address and password you provided at the following URL: </p>
  <p><a href="<?php zype_url('login'); ?>/"><?php zype_url('login'); ?>/</a></p>
  <p></p>

  <p></p>
  <p>
    Thanks again
  </p>
</div>
