<h3>Password Reset</h3>
<p>Beavis got your password? Click the following link to reset.</p>
<p><a href="<?php zype_url('profile');?>/reset-password/<?php echo $dictionary['password_token']; ?>/"><?php zype_url('profile');?>/reset-password/<?php echo $dictionary['password_token']; ?>/</a></p>
<p></p>
<p>If you did not request a password reset please disregard this email. If you suspect illicit activity, please contact <a href="mailto:apps@zype.com">support</a>.</p>
<p></p>
<p>
  Thanks for watching<br>
</p>
