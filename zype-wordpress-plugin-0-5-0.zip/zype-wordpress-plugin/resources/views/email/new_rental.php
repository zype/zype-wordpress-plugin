<div>
  <h3>New Rental</h3>
  <p>Thank you for your rental to <a href="<?php echo $dictionary['videoUrl']; ?>"><?php echo $dictionary['videoTitle']; ?></a>, we know you'll enjoy it!</p>
  <p>You can log in with the email address and password you provided at the following URL: </p>
  <p><a href="<?php zype_url('login'); ?>/"><?php zype_url('login'); ?>/</a></p>
  <p></p>
  
  <p>
    Thanks again<br>
  </p>
</div>
