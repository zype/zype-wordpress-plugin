<?php

namespace ZypeMedia\Models;

class Settings {

}
